export default [
    {en:'Saturday',bn:'শনিবার'},
    {en:'Sunday',bn:'রবিবার'},
    {en:'Monday',bn:'সোমবার'},
    {en:'Tuesday',bn:'মঙ্গলবার'},
    {en:'Wednesday',bn:'বুধবার'},
    {en:'Thursday',bn:'বৃহস্পতিবার'},
    {en:'Friday',bn:'শুক্রবার'}
]