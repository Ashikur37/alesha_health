export default {
    1:{
        'en':'Per Visit',
        'bn':'প্রতি সাক্ষাত',
    },
    2:{
        'en':'Per Minutes',
        'bn':'প্রতি মিনিট',
    }
}